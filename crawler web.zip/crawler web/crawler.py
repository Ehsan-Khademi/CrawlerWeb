import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import os
from concurrent.futures import ThreadPoolExecutor, as_completed


def fetch_page(url):

    try:
        response = requests.get(url)
        response.raise_for_status()
        return url, response.text
    except requests.RequestException as e:
        print(f'Failed to fetch {url}: {e}')
        return url, None


def extract_json_urls(page_content, base_url):

    if page_content is None:
        return set()
    soup = BeautifulSoup(page_content, 'html.parser')
    json_urls = set()

    # Find all links on the page
    for a_tag in soup.find_all('a', href=True):
        href = a_tag['href']

        if href.endswith('.json'):
            json_urls.add(urljoin(base_url, href))

    return json_urls


def extract_links(page_content, base_url):
    """Extract all links from the page content."""
    if page_content is None:
        return set()
    soup = BeautifulSoup(page_content, 'html.parser')
    links = set()


    for a_tag in soup.find_all('a', href=True):
        href = a_tag['href']

        full_url = urljoin(base_url, href)
        links.add(full_url)

    return links


def download_json(json_url):

    try:
        response = requests.get(json_url)
        response.raise_for_status()

        filename = os.path.basename(urlparse(json_url).path)
        os.makedirs('json_files', exist_ok=True)
        filepath = os.path.join('json_files', filename)

        with open(filepath, 'wb') as f:
            f.write(response.content)
        print(f'Saved JSON file: {filename}')
    except requests.RequestException as e:
        print(f'Failed to download {json_url}: {e}')


def crawl_site(start_url, max_urls, max_workers):

    seen_urls = set()
    urls_to_visit = {start_url}
    urls_visited = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_url = {executor.submit(fetch_page, url): url for url in urls_to_visit}
        while future_to_url and urls_visited < max_urls:
            for future in as_completed(future_to_url):
                url, page_content = future.result()
                if url in seen_urls:
                    continue

                if page_content:
                    print(f'Visiting: {url}')
                    json_urls = extract_json_urls(page_content, url)
                    for json_url in json_urls:
                        download_json(json_url)

                    links = extract_links(page_content, url)
                    for link in links:
                        if link not in seen_urls and link not in urls_to_visit:
                            future_to_url[executor.submit(fetch_page, link)] = link

                seen_urls.add(url)
                urls_visited += 1
                print(f'Visited {urls_visited}/{max_urls} URLs')

                if urls_visited >= max_urls:
                    break

    print('Crawling finished.')


if __name__ == '__main__':
    start_url = 'https://huggingface.co/datasets/Targoman/TLPC'  # Replace with the URL you want to start crawling from
    max_urls = 20
    max_workers = 10
    crawl_site(start_url, max_urls, max_workers)
