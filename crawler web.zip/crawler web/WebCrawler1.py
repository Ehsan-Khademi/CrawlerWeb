import asyncio
import aiohttp
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import chardet
import re
from datetime import datetime

class AsyncMultiSiteWebCrawler:
    def __init__(self, start_urls, max_pages=100, timeout=10):
        self.start_urls = start_urls
        self.max_pages = max_pages
        self.visited = set()
        self.queue = asyncio.Queue()
        for url in start_urls:
            self.queue.put_nowait(url)
        self.found_urls = []
        self.extracted_data = []
        self.timeout = timeout

    async def fetch_page(self, session, url):
        try:
            async with session.get(url, ssl=False, timeout=self.timeout) as response:
                if response.status == 200:
                    content = await response.read()
                    result = chardet.detect(content)
                    encoding = result['encoding'] if result['encoding'] is not None else 'utf-8'
                    try:
                        return content.decode(encoding)
                    except UnicodeDecodeError:
                        for enc in ['utf-8', 'iso-8859-1', 'latin1']:
                            try:
                                return content.decode(enc)
                            except UnicodeDecodeError:
                                continue
        except asyncio.TimeoutError:
            print(f"Timeout fetching {url}")
        except (aiohttp.ClientError, UnicodeDecodeError) as e:
            print(f"Error fetching {url}: {e}")
        return None

    def parse_links(self, html, base_url):
        soup = BeautifulSoup(html, 'lxml')
        links = []
        for anchor in soup.find_all('a', href=True):
            link = urljoin(base_url, anchor['href'])
            if link not in self.visited and not re.search(r'\{\{::letter\.\w+\}\}', link):
                links.append(link)
        return links

    def extract_data(self, html, url):
        soup = BeautifulSoup(html, 'lxml')
        title = soup.title.string if soup.title else 'No title'
        headings = [h.get_text() for h in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])]
        paragraphs = [p.get_text() for p in soup.find_all('p')]
        placeholders = re.findall(r'\{\{::letter\.(\w+)\}\}', html)
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return {
            'url': url, 
            'title': title, 
            'headings': headings, 
            'paragraphs': paragraphs, 
            'placeholders': placeholders,
            'timestamp': current_time
        }

    async def crawl(self, session):
        while not self.queue.empty() and len(self.visited) < self.max_pages:
            url = await self.queue.get()
            if url in self.visited or re.search(r'\{\{::letter\.\w+\}\}', url):
                continue

            print(f"Crawling: {url}")
            self.visited.add(url)
            html = await self.fetch_page(session, url)
            if html:
                data = self.extract_data(html, url)
                self.extracted_data.append(data)
                links = self.parse_links(html, url)
                for link in links:
                    if link not in self.visited:
                        await self.queue.put(link)
                        self.found_urls.append(link)

    async def start(self, num_workers=4):
        async with aiohttp.ClientSession() as session:
            tasks = [asyncio.create_task(self.crawl(session)) for _ in range(num_workers)]
            await asyncio.gather(*tasks)

if __name__ == "__main__":
    
    start_urls = ["https://huggingface.co/datasets/Targoman/TLPC"]
    crawler = AsyncMultiSiteWebCrawler(start_urls, max_pages=100, timeout=10)
    asyncio.run(crawler.start(num_workers=4))

    print("Crawling completed. Extracted Data:")
    for data in crawler.extracted_data:
        print(f"URL: {data['url']}")
        print(f"Title: {data['title']}")
        print(f"Headings: {data['headings']}")
        print(f"Paragraphs: {data['paragraphs']}")
        print(f"Placeholders: {data['placeholders']}")
        print(f"Timestamp: {data['timestamp']}")
        print("\n")
